
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">

<div class="collapse navbar-collapse">
<ul class="navbar-nav mr-auto mt-4 mt-lg-0 ross">
<li class="nav-item active">
<a href="#" class="nav-link"><?php echo $username; ?></a>
</li>

<li class="nav-item active" style="margin-left: 1050px;">
<a href="logout.php" class="nav-link">Logout</a>
</li>

</div>
</ul>
</nav>