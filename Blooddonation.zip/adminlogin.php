<?php
    session_start();
    include 'db/db.php';
    $message="";
    if(count($_POST)>0) 
    {
        $userName = $_POST["username"];
        $password = $_POST["password"];
        if ($userName == '' && $password == '') 
        {
            $message = "Username & Password Shouldn't Empty!";
        }
        elseif ($userName == '' && $password != '') 
        {
            $message = "Username  Shouldn't Empty!";
        }
        elseif ($userName != '' && $password == '') 
        {
            $message = "Password  Shouldn't Empty!";
        }
        else
        {
            $result = mysqli_query($conn,"SELECT * FROM `users` WHERE `username`='$userName' AND `password` = '$password'");
            $row = mysqli_fetch_array($result);
            if(is_array($row)) 
            {
                $_SESSION["id"] = $row['id'];
                $_SESSION["username"] = $row['username'];
                $_SESSION["password"] = $row['password'];

                header('Location:volenteerlist.php');
            }
            else
            {
                $message = "Invalid Username or Password!";
            }
        }
    }

?>

<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="style.css">
<title>login</title>
 </head>
 <body>
        
<?php include'header.php';?>
<?php 

if (isset($_GET['forget'])):

 ?>
<form method="POST" action="">
<div class="container login" style="margin-top: 100px;">
<h4 style="color:white;"><?php if($message!="") { echo $message; } ?></h4>
<div class="row">
<div class="col-md-4">
</div>

<div class="col-md-8">
<h4 class="clr">FORGET PASSWORD</h4>
</div>

</div>
<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-7">
<label class="clr"><b>UserName</b></label><br>
<input type="text" name="username" value="" placeholder="Enter User Name Here" class="form-control" required="">
</div>

</div>
<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-7">
<input type="submit" name="forget" value="Submit" class="btn btn-danger form-control">

</div>
    
</div>

<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-7">


</div>
    
</div>
</div>

</form>


<?php else: ?>
<h4 style="color:black;"><?php if($message!="") { echo $message; } ?></h4>
<form method="POST" action="">
<div class="container login" style="margin-top: 100px;">
<div class="row">
<div class="col-md-4">
</div>

<div class="col-md-6">
<h4 class="clr">LOGIN FORM</h4>


</div>

</div>
<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-7">
<label class="clr"><b>UserName</b></label><br>
<input type="text" name="username" value="" placeholder="Enter User Name Here" class="form-control" required="">
<label class="clr"><b>Password</b></label><br>  
<input type="text" name="password" placeholder="Enter Password Here" class="form-control" required="">
</div>

</div>
<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-7">
<b style="color: white;">Forget Password</b>  <a href="adminforget.php?forget">Please click here</a>

</div>
    
</div>

<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-7">
<input type="submit" name="submit" value="Login" class="btn btn-danger form-control">

</div>
    
</div>
</div>

<?php endif; ?>
</form><br><br>

<?php include'footer.php';?>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>