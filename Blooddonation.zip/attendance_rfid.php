<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "rfid";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }
$qs = str_replace('$', '', $_SERVER['QUERY_STRING']); // get rid of the $
$qs = str_replace('*', '', $qs); // get rid of the *
echo $qs;
$submissions = explode(',', $qs); // split the subs

$SID = ""; // store for sid
$MID = ""; // store for mid

// loop
for ($i = 0; $i < count($submissions); $i++) {
    $sections = explode('&', $submissions[$i]);

    if($i == 0) {
        $SID = $sections[0];
        $MID = $sections[1];
        $RFID = $sections[2];
        $DOT = $sections[3];
        $intime = $sections[4];
    } else {
        $RFID = $sections[0];
         $DOT = $sections[1];
       
    }
//Creates new record as per request
    //Connect to database
   
$string = $DOT;

$day = substr($string, 0, 2);
$month = substr($string, 2, 2);
$year = substr($string, 4, 4);

$hour = substr($string, 8, 2);
$min = substr($string, 10, 2);
$sec = substr($string, 12, 2);

$result_date = $day.'-'.$month.'-'.$year.' '.$hour.':'.$min.':'.$sec;

//echo $result;

  
    $sql="insert into silicondemo values('', '".$SID."','".$MID."','".$RFID."','".$result_date.",'".$intime."')";
	if ($result=mysqli_query($conn,$sql)) {
		  
$apiKey = urlencode('vQgXuKygRk8-P6BgdoFgC8ltfabTORsidNZgqAmUHk');
$que = "SELECT * FROM `student_registration` WHERE `rf_id` = '$RFID'";
$res = mysqli_query($conn,$que);
$row1 = mysqli_fetch_array($res);
$student_name = $row1['student_name'];
$array = $row1['mobile_number'];
    
    $sender = urlencode('SPRIVS');
    $message = rawurlencode("Dear Parent,
 
On the occasion of '$student_name' from '$result_date' to '$result_date'
Thanks and regards,
Sprivs.");
    $numbers =  $array;
    $data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
    $ch = curl_init('https://api.textlocal.in/send/');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    echo $response;

}
	}


	$conn->close();
?>

