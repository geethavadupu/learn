<?php 
session_start();
include 'db/db.php';
$username = $_SESSION['username'];
if ($username == '') {
  header('Location:logout.php');
}
?>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Blood Bank Update</title>
 </head>
 <body>
 		
<?php include'bankheader.php'?>
<div class="background1">
<div class="container">
<div class="row">
<div class="col-md-2">
</div>
<div class="col-md-10 ">
<h4 style="color: red;font-size: 30px;margin-top: 50px;">UPDATE BLOOD BANK DETAILS</h4><br><br><br>
</div>
</div>
<?php 
 include 'db/db.php';
 date_default_timezone_set("Asia/Kolkata");
 if(isset($_POST['update']))
 {
  $id = $_GET['id'];
  $organization_name=$_POST['organization_name'];
  $reg_no=$_POST['reg_no'];
  $mobile_no=$_POST['mobile_no'];
  $city=$_POST['city'];
  $name=$_POST['name'];
  $state=$_POST['state'];
  $address=$_POST['address'];
  $ap=$_POST['ap'];
  $an=$_POST['an'];
  $bp=$_POST['bp'];
  $bn=$_POST['bn'];
  $abp=$_POST['abp'];
  $abn=$_POST['abn'];
  $op=$_POST['op'];
  $onn=$_POST['onn'];
  $udateTime = date('d-m-Y h:i A');

  $query = "UPDATE `orphanage_registration` SET `organization_name` = '$organization_name',`reg_no` = '$reg_no',`mobile_no` = '$mobile_no',`city` = '$city', `name` = '$name',`state` = '$state',`address` = '$address',`ap` = '$ap',`an` = '$an',`bp` = '$bp',`bn` = '$bn',`abp` = '$abp',`abn` = '$abn',`op` = '$op',`onn` = '$onn',`udateTime` = '$udateTime' WHERE `orphanage_registration`.`id` = '$id'";
  mysqli_query($conn, $query);
  $query1 = "UPDATE `users` SET `username` = '$organization_name', `password` = '$password' WHERE `username` = 'organization_name'";
  mysqli_query($conn, $query1);
header('Location:bankprofileupdate.php');
  ?>
  <div class="alert alert-info" id="success-alert">
                <strong><?php echo $organization_name; ?></strong> Details Update Sussefully.
           </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script type="text/javascript">
     $("#success-alert").fadeTo(5000, 500).slideUp(1000, function(){
      $("#success-alert").slideUp(1000);
    });
           </script>
           <?php 
  }
 ?>
<?php if (isset($_GET['volenteerupdate'])):
include 'db/db.php';
$que = "SELECT * FROM `orphanage_registration` WHERE `organization_name` = '$username'";
$res = mysqli_query($conn,$que);
$row = mysqli_fetch_array($res);

 ?>
<form method="POST" action="">
<div class="row">
<div class="col-md-3">
<label><b>Organization Name</b></label>
<input type="text" name="organization_name" placeholder="Enter Name Here" class="form-control" value="<?php echo $row['organization_name']; ?>">
</div>
<div class="col-md-3">
<label><b>Reg No</b></label>
<input type="number" name="reg_no" value="<?php echo $row['reg_no']; ?>" class="form-control">
</div>
<div class="col-md-3">
<label><b>Mobile No</b></label><br>
<input type="number" name="mobile_no" placeholder="Enter Phone Number Here" class="form-control" value="<?php echo $row['mobile_no']; ?>">
</div>

</div><br>
<div class="row">

<div class="col-md-3">
<label><b>City</b></label>
<select name="city" class="form-control">
<option value="<?php echo $row['city']; ?>"><?php echo $row['city']; ?></option>
<option value="Tirupathi">Tirupathi</option>
<option value="Vishakapatnam">Vishakapatnam</option>
<option value="Vijayawada">Vijayawada</option>
<option value="Guntur">Guntur</option>
</select>
</div>

<div class="col-md-3">
<label><b>State</b></label>
<select name="state" required="" class="form-control">
<option value="<?php echo $row['state']; ?>"><?php echo $row['state']; ?></option>
<option value="Andhrapradesh">Andhra pradesh</option>
<option value="Bihar">Bihar</option>
<option value="Assam">Assam</option>
<option value="Goa">Goa</option>
</select>
</div>
<div class="col-md-3">
<label><b>CP Name</b></label>
<input type="text" name="name" placeholder="Enter Name Here" class="form-control" value="<?php echo $row['name']; ?>">
</div>


</div>
<div class="row">
<div class="col-md-5">

<label><b>Address</b></label><br>
<textarea col="3" rows="4" name="address" class="form-control"><?php echo $row['address']; ?></textarea><br>
</div>
<div class="col-md-1">
<label><b>A+</b></label>
<input type="number" name="ap" class="form-control" value="<?php echo $row['ap']; ?>"><br>
<label><b>A-</b></label>
<input type="number" name="an" class="form-control" value="<?php echo $row['an']; ?>"><br>
</div>
<div class="col-md-1">
<label><b>B+</b></label>
<input type="number" name="bp" class="form-control" value="<?php echo $row['bp']; ?>"><br>
<label><b>B-</b></label>
<input type="number" name="bn" class="form-control" value="<?php echo $row['bn']; ?>"><br>
</div> 
<div class="col-md-1">
<label><b>AB+</b></label>
<input type="number" name="abp" class="form-control" value="<?php echo $row['abp']; ?>"><br>
<label><b>AB-</b></label>
<input type="number" name="abn" class="form-control" value="<?php echo $row['abn']; ?>"><br>
</div>
<div class="col-md-1">

<label><b>O+</b></label>
<input type="number" name="op" class="form-control" value="<?php echo $row['op']; ?>"><br>
<label><b>O-</b></label>
<input type="number" name="onn" class="form-control" value="<?php echo $row['onn']; ?>"><br>
</div>

</div>


<div class="row">
<div class="col-md-5">
</div>
<div class="col-md-4">
<input type="submit" name="update" class="btn btn-primary" value="Update Profile"></a>
</div>
</div>
</div>

</form>
<?php else:
include 'db/db.php';
$que1 = "SELECT * FROM `orphanage_registration` WHERE `organization_name` = '$username'";
$res1 = mysqli_query($conn,$que1);
$row1 = mysqli_fetch_array($res1);



 ?>

 
    <div class="row">
      <div class="col-md-4">
      <td> <b>Organization Name </b> : <?php echo $row1['organization_name']; ?></td>
      </div>
      <div class="col-md-4">
      <td><b>RegNo</b> : <?php echo $row1['reg_no']; ?></td>
        
      </div>
      <div class="col-md-4">
      <td><b>Mobile No</b> : <?php echo $row1['mobile_no']; ?></td>
        
      </div>
    </div><br>
     <div class="row">
      <div class="col-md-4">
      <td> <b>CP Name </b> : <?php echo $row1['name']; ?></td>
      </div>
      <div class="col-md-4">
      <td> <b>City </b> : <?php echo $row1['city']; ?></td>
        
      </div>
      <div class="col-md-4">
        
      <td><b>State</b> : <?php echo $row1['state']; ?></td>
      </div>
    </div><br>
    <div class="row">
      <div class="col-md-4">
      <td><b>Address</b> : <?php echo $row1['address']; ?></td>
      </div>

      <div class="col-md-2">
      <td><b>A+ </b> : <?php echo $row1['ap']; ?></td><br>
      <td><b>B+ </b> : <?php echo $row1['bp']; ?></td><br>
      <td><b>AB+ </b> : <?php echo $row1['abp']; ?></td><br>
      <td><b>O+</b> : <?php echo $row1['op']; ?></td><br>
      </div>
      <div class="col-md-2">
      <td><b>A- </b> : <?php echo $row1['an']; ?></td><br>
      <td><b>B- </b> : <?php echo $row1['bn']; ?></td><br>
      <td><b>AB- </b> : <?php echo $row1['abn']; ?></td><br>
      <td><b>O- </b> : <?php echo $row1['onn']; ?></td><br>
      </div>
      
      <div class="col-md-2">
    <td><b>Updated date and Time </b> : <?php echo $row1['udateTime']; ?></td><br>
    </div><br>
</div>
     <div class="row">

      <div class="col-md-6">
         
      </div>
      <div class="col-md-6">
      <a href="bankprofileupdate.php?volenteerupdate=<?php echo $username; ?>&id=<?php echo $row1['id']; ?>" class="btn btn-primary">Update Details click here</a>   
      </div>
    </div><br>
    
 
<?php endif; ?>
</div>
</div>
<?php include'footer.php';?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>































