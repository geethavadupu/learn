<?php 
session_start();
include 'db/db.php';
?>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Blood Bank Update</title>
 </head>
 <body>
    
<?php include'header.php'?>
<div class="background1">
<div class="container">
<div class="row">
<div class="col-md-2">
</div>
<div class="col-md-10 ">
<h4 style="color: red;font-size: 30px;margin-top: 50px;"> BLOOD AVAILABILITY DETAILS</h4><br><br><br>
</div>
</div>

<?php if (isset($_GET['id'])):
  $id = $_GET['id'];
$que = "SELECT * FROM `orphanage_registration` WHERE `id` = '$id'";
$res = mysqli_query($conn,$que);
$row1 = mysqli_fetch_array($res);

 ?>
 
    <div class="row">
      <div class="col-md-4">
      <td> <b>Organization Name </b> : <?php echo $row1['organization_name']; ?></td>
      </div>
      <div class="col-md-4">
      <td><b>RegNo</b> : <?php echo $row1['reg_no']; ?></td>
        
      </div>
      <div class="col-md-4">
      <td><b>Mobile No</b> : <?php echo $row1['mobile_no']; ?></td>
        
      </div>
    </div><br>
     <div class="row">
      <div class="col-md-4">
      <td> <b>CP Name </b> : <?php echo $row1['name']; ?></td>
      </div>
      <div class="col-md-4">
      <td> <b>City </b> : <?php echo $row1['city']; ?></td>
        
      </div>
      <div class="col-md-4">
        
      <td><b>State</b> : <?php echo $row1['state']; ?></td>
      </div>
    </div><br>
    <div class="row">
      <div class="col-md-4">
      <td><b>Address</b> : <?php echo $row1['address']; ?></td>
      </div>

      <div class="col-md-2">
      <td><b>A+ </b> : <?php echo $row1['ap']; ?></td><br>
      <td><b>B+ </b> : <?php echo $row1['bp']; ?></td><br>
      <td><b>AB+ </b> : <?php echo $row1['abp']; ?></td><br>
      <td><b>O+</b> : <?php echo $row1['op']; ?></td><br>
      </div>
      <div class="col-md-2">
      <td><b>A- </b> : <?php echo $row1['an']; ?></td><br>
      <td><b>B- </b> : <?php echo $row1['bn']; ?></td><br>
      <td><b>AB- </b> : <?php echo $row1['abn']; ?></td><br>
      <td><b>O- </b> : <?php echo $row1['onn']; ?></td><br>
      </div>
      
      <div class="col-md-2">
    <td><b>Updated date and Time </b> : <?php echo $row1['udateTime']; ?></td><br>
    </div><br>
</div>
     <div class="row">

      <div class="col-md-6">
         
      </div>
      <div class="col-md-6">
      <a href="search.php?find=<?php echo $row1['city']; ?>" class="btn btn-warning">Back to list</a>   
      </div>
    </div><br>
    
 
<?php endif; ?>
</div>
</div>
<?php include'footer.php';?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>































