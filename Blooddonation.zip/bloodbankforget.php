<?php
    session_start();
    include 'db/db.php';
    $message="";


    if (isset($_POST['submit1'])) {
        $username = $_POST['userName'];
            $query = "SELECT * FROM `orphanage_registration` WHERE `organization_name` = '$username' AND `status` = 1 ";
            $res = mysqli_query($conn,$query);
            $row1 = mysqli_fetch_array($res);
    echo("<script>window.location = 'bloodbankforget.php?username1=$username';</script>");

    }

?>

<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="style.css">
<title>login</title>
 </head>
 <body>
 		
<?php include'header.php';?>
<?php 

if (isset($_GET['forget'])):

 ?>
<form method="POST" action="">
<div class="container login" style="margin-top: 100px;">
<h4 style="color:white;"><?php if($message!="") { echo $message; } ?></h4>
<div class="row">
<div class="col-md-4">
</div>

<div class="col-md-8">
<h4 class="clr">FORGET PASSWORD</h4>


</div>

</div>
<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-7">
<label class="clr"><b>UserName</b></label><br>
<input type="text" name="userName" value="" placeholder="Enter User Name Here" class="form-control" required="">
</div>

</div>
<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-7">
<input type="submit" name="submit1" value="Submit" class="btn btn-danger form-control">

</div>
	
</div>

<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-7">


</div>
    
</div>
</div>

</form>


<?php else: ?>
    
<h4 style="color:black;"><?php if($message!="") { echo $message; } ?></h4>
<form method="POST" action="">
<div class="container login" style="margin-top: 100px;">
<div class="row">
<div class="col-md-2">
</div>

<div class="col-md-8">
<h4 class="clr">LOGIN CREDENTIALS</h4>


</div>

</div>
<?php 

 if (isset($_GET['username1'])) {
       $username = $_GET['username1'];
            $query1 = "SELECT * FROM `orphanage_registration` WHERE `organization_name` = '$username' AND `status` = 1 ";
            $res1 = mysqli_query($conn,$query1);
            $row11 = mysqli_fetch_array($res1);
    // echo("<script>window.location = 'forget.php?username=$username1';</script>");

    }
     ?>
<div class="row">
<div class="col-md-2">
</div>
<div class="col-md-7">
<label class="clr"><b>UserName</b></label><br>
<input type="text" name="username" value="<?php echo $row11['organization_name'] ?>" class="form-control" readonly="">
<label class="clr"><b>Password</b></label><br>  
<input type="text" name="password" class="form-control" value="<?php echo $row11['password']; ?>" readonly="">
</div>

</div> <br><br>
<div class="row">
<div class="col-md-2">
</div>
<div class="col-md-8">
<b style="color: white;"> Login Again</b> <a href="bloodbanklogin.php">Please click here</a>

</div>
    
</div>

</div>

<?php endif; ?>
</form><br><br>

<?php include'footer.php';?>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>