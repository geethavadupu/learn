<?php 
$conn = mysqli_connect("localhost","root","","blooddonation");
if (!$conn) {
echo "Could not connect".mysqli_error();
}

 ?>