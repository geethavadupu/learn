<div class="footer">
<p><a href="adminlogin.php">ONLINE BLOOD DONATION MANAGEMENT SYSTEM</a>    Design and Developed by Team Members(CSE A) 2020, under the guidence of SUPRIYA.</p>
</div>

<style>
	
	.login{
		background-color: #262624;
		height: 350px;
		width: 500px;
		margin-top: 140px;

	}
	.submit{
		background-color: #4682e3;
		color: white;
	}
	.new{
		background-image:url("images/new.jpg");
		height: 900px;
    
	}
	.background2{
	background-image:url("images/bg6.jpg");
		height: 600px;
    background-repeat: no-repeat;
 background-attachment: fixed;
  background-position:left; 
}
.logo{
	background-image:url("images/bg6.jpg");
	
    background-repeat: no-repeat;
 background-attachment: fixed;
  background-position:left; 
}	


.background{
	background-image:url("images/bloodlogo.jpg");
		height: 600px;
    background-repeat: no-repeat;
 background-attachment: fixed;
  background-position:left; 
}
	
.background1{
	background-image:url("images/bloodlogo.jpg");
		height: 600px;
    background-repeat: no-repeat;
 background-attachment: fixed;
  background-position:right; 
}
	



.form-inline{
	margin-right: 250px;
}

.w-100{
height:86.3vh;
}
.footer{
padding: 1px;
 background-color: #1c8494;
text-align: center;
color: white;
}
h4,label{
color: black;
}

.acc{
height: 200px;
width: 200px;
}

.lok{
margin-top:90px;
color:black;
}
.ross{
margin-left: 50px;
}
span{
	color: red;
}

.clr{
	color: white;
	margin-top: 20px;
}


.logo-title{
	color: #0997e3;
}
.colorss{
		color: #0997e3;
	
}
.dr{
    margin-left:96px;
  }
  .fa-television {
    background: #3B5998;
    color: white;
    padding: 8px;
    border-radius: 16px;
   margin-top:20px; 
  }
  .fa-facebook {
  background: #3B5998;
  color: white;
 padding: 10px;
    border-radius: 16px;
   margin-top:20px; 
}

.fa-skype {
  background:  #3B5998;
  color: white;
   padding: 10px;
    border-radius: 16px;
   margin-top:20px; 
}
.fa-android {
  background:  #3B5998;
  color: white;
  padding: 10px;
    border-radius: 16px;
   margin-top:20px; 
}
.fa-google {
  background:#3B5998;
  color: white;
 padding: 10px;
    border-radius: 16px;
   margin-top:20px; 
}
.fa-rss {
  background: #3B5998;
  color: white;
   padding: 10px;
    border-radius: 16px;
   margin-top:20px; 
}
.fa-yahoo {
  background: #3B5998;
  color: white;
  padding: 10px;
    border-radius: 16px;
   margin-top:20px; 
}
 
.fa-rss {
  background: #ff6600;
  color: white;
}
.fa-twitter {
  background: #55ACEE;
  color: white;
   padding: 10px;
    border-radius: 16px;
   margin-top:20px; 
}
.fa-linkedin {
  background: #007bb5;
  color: white;
   padding: 10px;
    border-radius: 16px;
   margin-top:20px; 
}
.fa-skype {
  background: #00aff0;
  color: white;
}



.fa-youtube {
  background: #bb0000;
  color: white;
 padding: 10px;
    border-radius: 16px;
   margin-top:20px; 
}
  .principal{
    margin-left: 90px;
    width: 260px;
    height: 250px;
  }
  .nadha{
    margin-left: 100px;

    width: 1430px;

  }
  
  .btn{
    margin-top: 30px;
  }
   .bg1{
   background-image:url("images/bg1.jpg");
   height: auto;
 }
  .aits{
    color: #d42724;


  }
  .hr-1{
    border: 1px solid #495091;
    width: 1470px;
  }

.nav{
  margin-left:370px;
  background-color: #4580f5;
}

  
      .logo-title{
          font-size:25px;
      }
        img{
            height: 100px;
            width: 100px;
        }
        .autonomous{
            color:#ab271d;
        }
        .ram{
           font-size:12px;
         }
       .bg{
        background-image:url("images/bg.jpg");
       }
 

 *{
    margin: 0;
    padding: 0;
     }
 .cards{
    height: 650px;
    width:450px;
    background-color: #cdd2d4;
    
    margin-top: 40px;
      box-shadow: 10px 10px 5px grey;
  }
 .cards img{
   height: 200px;
    width: 90%;
    padding: 10px 10px 10px 10px;

  }
  
 
.footer{  
  color: white;
  background-color: #232423; 
  width: 1350px;
  padding-top: 30px ;
 padding-left: 20px;
 text-align: center
 padding: 1px;

}

.padding{
  padding: 40px;
}

 *{
    margin: 0;
    padding: 0;
     }
.colorbg img{
height: 200px;
width:100%;
 padding: 10px 10px 10px 10px ;
}
.colorbg{
height: 250px;
    width:450px;
    background-color:white;
    overflow: hidden;

}

.navtop{
	margin-top: 20px;
}


 *{
    margin: 0;
    padding: 0;
     }
 .cards{
    height: 250px;
    width:450px;
    background-color:#fff;
    overflow: hidden;
    margin-top: 40px;
      box-shadow: 10px 10px 5px grey;
  }
 .cards img{
   height: 350px;
    width: 100%;
    padding: 10px 10px 10px 10px;

  }



</style>