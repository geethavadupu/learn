<nav class="navbar navbar-expand-lg navbar-dark bg-dark">

<div class="collapse navbar-collapse">
<ul class="navbar-nav mr-auto mt-4 mt-lg-0 ross">
<li class="nav-item active">
<a href="index.php" class="nav-link">Home</a>
</li>
<li class="nav-item active">
<a href= "gallery.php" class="nav-link">Gallery</a>
</li>
<li class="nav-item active">
<a href="news.php" class="nav-link">News</a>
</li>
<li class="nav-item active">
<a href="volunteer.php" class="nav-link">Volenteer Registration</a>
</li>
<li class="nav-item active">
<a href="orphanage.php" class="nav-link">Orphanage/Blood Bank</a>
</li>
<li class="nav-item active">
<a href="login.php" class="nav-link">Login</a>
</li>


</div>


</ul>
</nav>