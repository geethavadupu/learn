<?php 
session_start();
include 'db/db.php';
if (isset($_POST['submit'])) {
  $find = $_POST['find_city'];
  echo ("<script>window.location = 'search.php?find=$find';</script>");
}
?>
	<html lang="en">
<head>
<title>Home</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> 
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script> 
  
 </head>
 <body>
 	
<div class="container-fluid">
<img src="images/collegeName.png" style="width: 1320px;height: 150px;">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="collapse navbar-collapse">
<ul class="navbar-nav mr-auto mt-4 mt-lg-0 ross">
<li class="nav-item active">
<a href="index.php" class="nav-link">Home</a>
</li>
<li class="nav-item active">
<a href= "gallery.php" class="nav-link">Gallery</a>
</li>
<li class="nav-item active">
<a href="news.php" class="nav-link">News</a>
</li>
<li class="nav-item active">
<a href="volunteer.php" class="nav-link">Volenteer Registration</a>
</li>
<li class="nav-item active">
<a href="orphanage.php" class="nav-link">Orphanage/Blood Bank</a>
</li>
<li class="nav-item active">
<a href="login.php" class="nav-link">Login</a>
</li>


</div>
<?php 
                            
                            $query = "SELECT * FROM `orphanage_registration` GROUP BY `city`";
                            $result = mysqli_query($conn,$query);
                          ?>
<form method="POST" class="form-inline my-4 my-lg-0">
   <select class="form-control mr-sm-4" name="find_city">
                              <option value=""><h3>--SELECT CITY--</h3></option>
                                <?php while($row = mysqli_fetch_array($result)){ ?>
                                  <option value="<?php echo $row['city']; ?>"><?php echo $row['city']; ?></option>
                                <?php } ?>
                              </select>
<input class="form-control mr-sm-4 submit" name="submit" type="submit" value="Submit">

</form>
</ul>
</nav>
    <!-- <img src="images/collegeName.png" style="width: 1349px;"> -->


<div class="bd-example">
  <div id="carouselExampleCaptions" class="carousel slide">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
	  <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
	  <li data-target="#carouselExampleCaptions" data-slide-to="4"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="images/slide.jpeg" class="d-block w-100">
        <div class="carousel-caption d-none d-md-block">
         
        </div>
      </div>
      <div class="carousel-item">
        <img src="images/donate.jpg" class="d-block w-100">
        <div class="carousel-caption d-none d-md-block">
         
        </div>
      </div>
      <div class="carousel-item">
        <img src="images/bloods.jpg" class="d-block w-100">
        <div class="carousel-caption d-none d-md-block">
          
        </div>
      </div>
	   <div class="carousel-item">
        <img src="images/types.jpg" class="d-block w-100">
        <div class="carousel-caption d-none d-md-block">
         
        </div>
      </div>
     </div>
<a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
<div class="footer">
<p>ONLINE BLOOD DONATION MANAGEMENT SYSTEM Design and Developed by Team Members(CSE A) 2020, under the guidence of SUPRIYA.</p>
</div>


  </body>
</html>	