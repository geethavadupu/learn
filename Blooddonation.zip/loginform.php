<form method="POST" action="" class="lok">
	<div class="container">
<div class="row">
<div class="col-md-5">
</div>
<div class="col-md-3">
<h4 class="lo">LOGIN FORM</h4>
</div>
<div class="col-md-4">
</div>
</div>
<div class="row">
<div class="col-md-4">
</div>
<div class="col-md-3">
<label class="lo"><b>User Name<span style="font-size:25px;">*</span></b></label>
<input type="text" name="" value="" placeholder="Enter User Name Here" class="form-control" required="">
<label class="lo"><b>Password</b></label>
<input type="password" name="" value="" placeholder="Enter Password Here" class="form-control" required=""><br>
</div>
<div class="col-md-4">
</div>
</div>
<div class="row">
<div class="col-md-5">
</div>
<div class="col-md-4">
<button type="" name="" value="" placeholder="" class="btn btn-primary">login</button>
</div>
<div class="col-md-3">
</div>
</div>
</div>
</form>