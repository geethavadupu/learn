
<div class="container-fluid">
        <div class="row">
    <div class="col-md-3">
    <img src="images/bg6.jpg">
    </div>
    <div class="col-md-6">
    <a href="#"><span class="logo-title">Annamacharya Institute of Technology & Sciences, Tirupati</span></a><br>
       <div class="row">
        <div class="col-md-4">
        </div>  
        <div class="col-md-4">
         <span class="autonomous">(Autonomous)</span>
        </div>
 </div>
 <div class="row">
        <div class="col-md-1">
        </div>
        <div class="col-md-10">
          <a href="#" class="ram colorss"> <span class="colorss">Approved by AICTE, New Delhi & Permanent Affiliation to JNTUA, Anantapuramu.</span></a><br>  
          <a href="#" class="ram"> <span class="colorss">Two B.Tech Programmes (CSE & ECE) are accredited by NBA, New Delhi.</span></a>

        </div>
        <div class="row">
          <div class="col-md-1">
          </div>
           <div class="col-md-12">
           <a href="#" class="ram"> <span class="colorss"> Accredited by NAAC with 'A' Grade, Bangalore. Accredited by Institution of Engineers (India), KOLKATA.</span></a><br>
           <a href="#" class="ram"> <span class="colorss">A-grade awarded by AP Knowledge Mission. Recognized under sections 2(f) & 12(B) of UGC Act 1956.</span></a>
          </div>
        </div>
 </div>
    </div>

  </div>
     
</div>