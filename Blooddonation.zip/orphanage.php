<?php 
session_start();
include 'db/db.php';

?>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Blood bank</title>
 </head>
 <body>
 	
<?php include'header.php';?>
<br>
<div class="background2">
<div class="container">

<div class="row">
<div class="col-md-2">
</div>
<div class="col-md-10">
<h4 class="lok" style="color: red;font-size: 30px;margin-top: 50px;">BLOOD BANK REGISTRATION FORM</h4>
</div>

</div><br>
<?php 
 include 'db/db.php';
 date_default_timezone_set("Asia/Kolkata");
 if(isset($_POST['submit']))
 {
  $organization_name=$_POST['organization_name'];
  $reg_no=$_POST['reg_no'];
  $name=$_POST['name'];
  $mobile_no=$_POST['mobile_no'];
  $city=$_POST['city'];
  $state=$_POST['state'];
  $address = $_POST['address'];
  $password = $_POST['password'];
  $ap=$_POST['ap'];
  $an=$_POST['an'];
  $bp=$_POST['bp'];
  $bn=$_POST['bn'];
  $abp=$_POST['abp'];
  $abn=$_POST['abn'];
  $op=$_POST['op'];
  $onn=$_POST['onn'];
  $dateTime = date('d-m-Y h:i A');

  $query = "INSERT INTO `orphanage_registration`(organization_name,reg_no,name,mobile_no,city,state,address,dateTime,password,ap,an,bp,bn,abp,abn,op,onn) VALUES('$organization_name','$reg_no','$name','$mobile_no','$city','$state', '$address','$dateTime','$password','$ap','$an','$bp','$bn','$abp','$abn','$op','$onn')";
  mysqli_query($conn, $query);
  $query1 = "INSERT INTO `users`(username,password,dateTime) VALUES('$organization_name','$password','$dateTime')";
  mysqli_query($conn, $query1);
  ?>
  <div class="alert alert-info" id="success-alert">
                <strong><?php echo $organization_name; ?></strong> Registred Sussefully You Are The Member Of Blood Donation.
           </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script type="text/javascript">
     $("#success-alert").fadeTo(5000, 500).slideUp(1000, function(){
      $("#success-alert").slideUp(1000);
    });
           </script>
           <?php 
  }

 ?>
<form method="POST" action="">
<div class="row">
<div class="col-md-2">
</div>
<div class="col-md-3">
<label class="mn"><b>Organization</b></label>
<input type="text" name="organization_name" value="" placeholder="Enter Organization Here" class="form-control">
</div>
<div class="col-md-3">
<label class="mn"><b>mobile No</b></label>
<input type="text" name="mobile_no" pattern="[1-9]{1}[0-9]{9}" placeholder="Enter Phone Number Here" maxlength="10" class="form-control">
</div>
<div class="col-md-3">
<label class="mn"><b>Registration Number</b></label>
<input type="number" name="reg_no" value="" placeholder="Enter Phone Number Here" class="form-control">
</div>
</div>
<div class="row">

<div class="col-md-2"></div>
<div class="col-md-3">
  <label class="mn"><b>Person Name</b></label>
<input type="text" name="name" value="" placeholder="Enter Name Here" class="form-control">
</div>


<div class="col-md-3">
<label class="mn"><b>State</b></label>
<select name="state" class="form-control" id="countySel">
<option value="" selected="selected">----------Select State--------------</option>

</select>
</div>

<div class="col-md-3">
<label class="mn"><b>City</b></label>
<select name="city" class="form-control" id="stateSel">
<option value="" selected="selected">-----------Select City-----------</option>

</select>

</div>

<script type="text/javascript">
var stateObject = {
"Andhra Pradesh": { "Anantapur": ["new Delhi", "North Delhi"],
"Chittoor": ["Thiruvananthapuram", "Palakkad"],
"East Godavari": ["North Goa", "South Goa"],
"Krishna": ["North Goa", "South Goa"],
"Visakhapatnam": ["North Goa", "South Goa"],
},
"Telangana": { "Hyderabad": ["new Delhi", "North Delhi"],
"Nalgonda": ["Thiruvananthapuram", "Palakkad"],
"Khammam": ["North Goa", "South Goa"],
"Nizamabad": ["North Goa", "South Goa"],
"Vikarabad": ["North Goa", "South Goa"],
},
"Tamil Nadu": { "Chennai": ["new Delhi", "North Delhi"],
"Kanchipuram": ["Thiruvananthapuram", "Palakkad"],
"Vellore": ["North Goa", "South Goa"],
"Tiruchirappalli": ["North Goa", "South Goa"],
"Madurai": ["North Goa", "South Goa"],
},
"Bihar": { "Aurangabad": ["new Delhi", "North Delhi"],
"Kishanganj": ["Thiruvananthapuram", "Palakkad"],
"Bhojpur": ["North Goa", "South Goa"],
"Araria": ["North Goa", "South Goa"],
"Bhagalpur": ["North Goa", "South Goa"],
},

}
window.onload = function () {
var countySel = document.getElementById("countySel"),
stateSel = document.getElementById("stateSel"),
districtSel = document.getElementById("districtSel");
for (var country in stateObject) {
countySel.options[countySel.options.length] = new Option(country, country);
}
countySel.onchange = function () {
stateSel.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done 
for (var state in stateObject[this.value]) {
stateSel.options[stateSel.options.length] = new Option(state, state);
}
}

}
</script>

</div>
<div class="row">
	<div class="col-md-2"></div>
  <div class="col-md-3">
<label class="mn"><b>Address</b></label><br>
<textarea  name="address" col="3" rows="4" class="form-control"></textarea>
	</div>
	<div class="col-md-3">

<label class="mn"><b>Password</b></label><br>
<input type="text" name="password" class="form-control">
</div>
 <div class="col-md-1">
<label><b>A+</b></label>
<input type="number" name="ap" class="form-control"><br>
<label><b>A-</b></label>
<input type="number" name="an" class="form-control"><br>
</div>
<div class="col-md-1">
<label><b>B+</b></label>
<input type="number" name="bp" class="form-control" ><br>
<label><b>B-</b></label>
<input type="number" name="bn" class="form-control"><br>
</div> 
<div class="col-md-1">
<label><b>AB+</b></label>
<input type="number" name="abp" class="form-control"><br>
<label><b>AB-</b></label>
<input type="number" name="abn" class="form-control"><br>
</div>
<div class="col-md-1">

<label><b>O+</b></label>
<input type="number" name="op" class="form-control"><br>
<label><b>O-</b></label>
<input type="number" name="onn" class="form-control"><br>
</div>
</div>
<div class="row">
<div class="col-md-5">
</div>
<div class="col-md-4">
<input type="submit" name="submit" placeholder="" class="btn btn-primary" value="Register">
</div>
</div>

</div>
</div>
</form>
<?php include'footer.php'?>	


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>