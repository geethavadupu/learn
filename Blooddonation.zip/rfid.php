<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "demo";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }
$qs = str_replace('$', '', $_SERVER['QUERY_STRING']); // get rid of the $
$qs = str_replace('*', '', $qs); // get rid of the *
echo $qs;
$submissions = explode(',', $qs); // split the subs

$SID = ""; // store for sid
$MID = ""; // store for mid

// loop
for ($i = 0; $i < count($submissions); $i++) {
    $sections = explode('&', $submissions[$i]);

    if($i == 0) {
        $SID = $sections[0];
        $MID = $sections[1];
        $RFID = $sections[2];
        $DOT = $sections[3];
        $intime = $sections[4];
    } else {
        $RFID = $sections[0];
         $DOT = $sections[1];
       
    }
//Creates new record as per request
    //Connect to database
   
$string = $DOT;

$day = substr($string, 0, 2);
$month = substr($string, 2, 2);
$year = substr($string, 4, 4);

$hour = substr($string, 8, 2);
$min = substr($string, 10, 2);
$sec = substr($string, 12, 2);

$result_date = $day.'-'.$month.'-'.$year.' '.$hour.':'.$min.':'.$sec;

//echo $result;

    $sql="insert into silicondemo values('', '".$SID."','".$MID."','".$RFID."','".$result_date.",'".$intime."')";
  $quer = "SELECT * FROM `student_registration` WHERE `rf_id` = '$RFID'";
  $res = mysql_query($conn,$quer);
  $row = mysqli_fetch_array($res);
  $student_name = $row['student_name'];
  $mobile_number = $row['mobile_number'];
	if ($result=mysqli_query($conn,$sql)) {
		  
// Account details
$apiKey = urlencode('XIZyoOW8Xp8-HRYS9hQoBTuEMi7PHm5Bl9qU9zYFUJ');
// Message details

$sender = urlencode('TXTLCL');
$message = rawurlencode('Dear Parent,

Your child $student_name is present on $result_date at $intime

Thanks & Regards
Sprivs');
 
$numbers = $mobile_number;
 
// Prepare data for POST request
$data = array('apikey' => $apiKey, 'numbers' => $numbers, 'sender' => $sender, 'message' => $message);
// Send the POST request with cURL
$ch = curl_init('https://api.textlocal.in/');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);
// Process your response here
echo $response;

		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}
	}


	$conn->close();
?>

