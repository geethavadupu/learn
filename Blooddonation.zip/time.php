<?php 
 include 'db/db.php';
 date_default_timezone_set("Asia/Kolkata");
 if(isset($_POST['submit']))
 {
  $intime=$_POST['intime'];
  $outtime=$_POST['outtime'];
  

  $query = "INSERT INTO `timings`(intime,outtime) VALUES('$intime','$outtime')";
  mysqli_query($conn, $query);
  ?>
  <div class="alert alert-info" id="success-alert">
                <strong><?php echo $intime; ?></strong> Registred Sussefully You Are The Member Of Blood Donation Group.
           </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script type="text/javascript">
     $("#success-alert").fadeTo(5000, 500).slideUp(1000, function(){
      $("#success-alert").slideUp(1000);
    });
           </script>
           <?php 
  }

 ?>

<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="style.css">
<title>login</title>
 </head>
 <body>
 		
<?php include'header.php';?>

<form method="POST" action="">
<div class="container login" style="margin-top: 100px;">
<div class="row">
<div class="col-md-4">
</div>

<div class="col-md-6">
<h4 class="clr">LOGIN FORM</h4>
</div>

</div>
<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-7">
<label class="clr"><b>UserName</b></label><br>
<input type="time" name="intime" value="" placeholder="Enter User Name Here" class="form-control" required="">
<label class="clr"><b>Password</b></label><br>	
<input type="time" name="outtime"  class="form-control" required="">
</div>

</div>
<div class="row">
<div class="col-md-3">
</div>
<div class="col-md-7">
<input type="submit" name="submit" value="Login" class="btn btn-danger form-control">

</div>
	
</div>
</div>

</form><br><br><br>

<?php include'footer.php';?>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>