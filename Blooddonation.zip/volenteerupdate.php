<?php 
session_start();
include 'db/db.php';
$username = $_SESSION['username'];
if ($username == '') {
  header('Location:logout.php');
}
?>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Volenteer Registration</title>
 </head>
 <body>
 		
<?php include'adminheader.php'?>
<div class="background1">
<div class="container">
<div class="row">
<div class="col-md-2">
</div>
<div class="col-md-10 ">
<h4 style="color: red;font-size: 30px;margin-top: 50px;">UPDATE VOLUNTEER DETAILS</h4><br><br><br>
</div>
</div>
<?php 
 include 'db/db.php';
 date_default_timezone_set("Asia/Kolkata");
 if(isset($_POST['update']))
 {
  $id = $_GET['id'];
  $volenteer_name=$_POST['volenteer_name'];
  $blood_group=$_POST['blood_group'];
  $mobile_no=$_POST['mobile_no'];
  $city=$_POST['city'];
  $state=$_POST['state'];
  $address=$_POST['address'];
  $udateTime = date('d-m-Y h:i A');

  $query = "UPDATE `volenteer_registration` SET `volenteer_name` = '$volenteer_name',`blood_group` = '$blood_group',`mobile_no` = '$mobile_no',`city` = '$city',`state` = '$state',`address` = '$address' WHERE `volenteer_registration`.`id` = '$id'";
  mysqli_query($conn, $query);
  $query1 = "UPDATE `users` SET `username` = '$volenteer_name', `password` = '$mobile_no' WHERE `volenteer_name` = '$volenteer_name'";
  mysqli_query($conn, $query1);
header('Location:volenteerupdate.php');
  ?>
  <div class="alert alert-info" id="success-alert">
                <strong><?php echo $volenteer_name; ?></strong> Details Update Sussefully You Are The Member Of Blood Donation Group.
           </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script type="text/javascript">
     $("#success-alert").fadeTo(5000, 500).slideUp(1000, function(){
      $("#success-alert").slideUp(1000);
    });
           </script>
           <?php } ?>
           <?php 
           if (isset($_GET['id1'])) {
             $id1 = $_GET['id1'];
             $qu = "DELETE FROM `volenteer_registration` WHERE `volenteer_registration`.`id` = '$id1' AND `volenteer_name` = '$username' ";
            mysqli_query($conn,$qu);
            echo '<script language="javascript">';
echo 'alert("Your Account was Deleted successfully..!")';
echo '</script>';
    echo("<script>window.location = 'index.php';</script>");


  }

 ?>
<?php if (isset($_GET['volenteerupdate'])):
include 'db/db.php';
$que = "SELECT * FROM `volenteer_registration` WHERE `volenteer_name` = '$username'";
$res = mysqli_query($conn,$que);
$row = mysqli_fetch_array($res);

 ?>
<form method="POST" action="">
<div class="row">
<div class="col-md-3">
<label><b>Volunteer Name</b></label>
<input type="text" name="volenteer_name" placeholder="Enter Name Here" class="form-control" value="<?php echo $row['volenteer_name']; ?>">
</div>
<div class="col-md-3">
<label><b>Blood Group</b></label>
<select name="blood_group" class="form-control">
<option value="<?php echo $row['blood_group']; ?>"><?php echo $row['blood_group']; ?></option>
<option value="A+ve">A+ve</option>
<option value="A-ve">A-ve</option>
<option value="B+ve">B+ve</option>
<option value="B-ve">B-ve</option>
<option value="O+ve">O+ve</option>
<option value="O-ve">O-ve</option>
</select>
</div>
<div class="col-md-3">
<label><b>Mobile No</b></label><br>
<input type="number" name="mobile_no" placeholder="Enter Phone Number Here" class="form-control" value="<?php echo $row['mobile_no']; ?>">
</div>

</div><br>
<div class="row">

<div class="col-md-3">
<label><b>City</b></label>
<select name="city" class="form-control">
<option value="<?php echo $row['city']; ?>"><?php echo $row['city']; ?></option>
<option value="tirupathi">Tirupathi</option>
<option value="renigunta">Vishakapatnam</option>
<option value="chennai">Vijayawada</option>
<option value="hyderabad">Guntur</option>
</select>
</div>

<div class="col-md-3">
<label><b>State</b></label>
<select name="state" required="" class="form-control">
<option value="<?php echo $row['state']; ?>"><?php echo $row['state']; ?></option>
<option value="Andhrapradesh">Andhra pradesh</option>
<option value="Bihar">Bihar</option>
<option value="Assam">Assam</option>
<option value="Goa">Goa</option>
</select>
</div>
<div class="col-md-3">
<label><b>Address</b></label><br>
<textarea col="3" rows="4" name="address" class="form-control"><?php echo $row['address']; ?></textarea><br>
</div>

</div>

<div class="row">
<div class="col-md-5">
</div>
<div class="col-md-4">
<input type="submit" name="update" class="btn btn-primary" value="Update"></a>
</div>
</div>
</div>

</form>
<?php else:
include 'db/db.php';
$que1 = "SELECT * FROM `volenteer_registration` WHERE `volenteer_name` = '$username'";
$res1 = mysqli_query($conn,$que1);
$row1 = mysqli_fetch_array($res1);



 ?>

 
    <div class="row">
      <div class="col-md-4">
      <td> <b>Volenteer Name </b> : <?php echo $row1['volenteer_name']; ?></td>
      </div>
      <div class="col-md-4">
      <td><b>Blood Group</b> : <?php echo $row1['blood_group']; ?></td>
        
      </div>
      <div class="col-md-4">
      <td><b>Mobile No</b> : <?php echo $row1['mobile_no']; ?></td>
        
      </div>
    </div><br>
     <div class="row">
      <div class="col-md-4">
      <td> <b>City </b> : <?php echo $row1['city']; ?></td>
      </div>
      <div class="col-md-4">
      <td><b>State</b> : <?php echo $row1['state']; ?></td>
        
      </div>
      <div class="col-md-4">
      <td><b>Address</b> : <?php echo $row1['address']; ?></td>
        
      </div>
    </div><br>
     <div class="row">

      <div class="col-md-4">
         
      </div>
      <div class="col-md-3">
      <a href="volenteerupdate.php?volenteerupdate=<?php echo $username; ?>&id=<?php echo $row1['id']; ?>" class="btn btn-primary">Update Details click here</a>   
      </div>
      <div class="col-md-3">
      <a href="volenteerupdate.php?username=<?php echo $username; ?>&id1=<?php echo $row1['id']; ?>" class="btn btn-danger">Delete Account click here</a>   
      </div>
    </div><br>
    
 
<?php endif; ?>
</div>
</div>
<?php include'footer.php';?>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>































