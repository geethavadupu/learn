<?php 
session_start();
include 'db/db.php';

?>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Volenteer Registration</title>
 </head>
 <body>
 		
<?php include'header.php'?>
<div class="background1">
<div class="container">
<div class="row">
<div class="col-md-2">
</div>
<div class="col-md-10 ">
<h4 style="color: red;font-size: 30px;margin-top: 50px;">VOLUNTEER REGISTRATION FORM</h4><br><br><br>
</div>
</div>
<?php 
 include 'db/db.php';
 date_default_timezone_set("Asia/Kolkata");
 if(isset($_POST['submit']))
 {
  $volenteer_name=$_POST['volenteer_name'];
  $blood_group=$_POST['blood_group'];
  $mobile_no=$_POST['mobile_no'];
  $gender=$_POST['gender'];
  $city=$_POST['city'];
  $state=$_POST['state'];
  $address=$_POST['address'];
  $password=$_POST['password'];
  $dateTime = date('d-m-Y h:i A');

  $query = "INSERT INTO `volenteer_registration`(volenteer_name,blood_group,mobile_no,gender,city, state,address,dateTime,password) VALUES('$volenteer_name','$blood_group','$mobile_no','$gender','$city','$state','$address', '$dateTime','$password')";
  mysqli_query($conn, $query);
  $query1 = "INSERT INTO `users`(username,password,dateTime) VALUES('$volenteer_name','$password','$dateTime')";
  mysqli_query($conn, $query1);
  ?>
  <div class="alert alert-info" id="success-alert">
                <strong><?php echo $volenteer_name; ?></strong> Registred Sussefully You Are The Member Of Blood Donation Group.
           </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script type="text/javascript">
     $("#success-alert").fadeTo(5000, 500).slideUp(1000, function(){
      $("#success-alert").slideUp(1000);
    });
           </script>
           <?php 
  }

 ?>
<form method="POST" action="">
<div class="row">
<div class="col-md-3">
<label><b>Volunteer Name</b></label>
<input type="text" name="volenteer_name" placeholder="Enter Name Here" class="form-control">
</div>
<div class="col-md-3">
<label><b>Blood Group</b></label>
<select name="blood_group" class="form-control">
<option value="">-----Select Blood Group-----</option>
<option value="A+ve">A+ve</option>
<option value="A-ve">A-ve</option>
<option value="B+ve">B+ve</option>
<option value="B-ve">B-ve</option>
<option value="O+ve">O+ve</option>
<option value="O-ve">O-ve</option>
</select>
</div><br>
<div class="col-md-3">
<label><b>Mobile No</b></label>
<input type="text" pattern="[1-9]{1}[0-9]{9}" name="mobile_no" maxlength="10" class="form-control" placeholder="Enter Mobile Number"></div>

</div><br>
<div class="row">
<div class="col-md-3">
<label><b>Gender</b></label>
<select name="gender"  placeholder="Enter City Here" class="form-control">
<option value="">---------Select Gender--------</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
</select>
</div>


<div class="col-md-3">
<label><b>State</b></label>
<select name="state" required="" class="form-control" id="countySel">
<option value="" selected="selected">----------Select State----------</option>

</select>
</div>

<div class="col-md-3">
<label><b>City</b></label>
<select name="city" class="form-control" id="stateSel">
<option value="" selected="selected">----------Select City----------</option>

</select>

</div>
<script type="text/javascript">
var stateObject = {
"Andhra Pradesh": { "Anantapur": ["new Delhi", "North Delhi"],
"Chittoor": ["Thiruvananthapuram", "Palakkad"],
"East Godavari": ["North Goa", "South Goa"],
"Krishna": ["North Goa", "South Goa"],
"Visakhapatnam": ["North Goa", "South Goa"],
},
"Telangana": { "Hyderabad": ["new Delhi", "North Delhi"],
"Nalgonda": ["Thiruvananthapuram", "Palakkad"],
"Khammam": ["North Goa", "South Goa"],
"Nizamabad": ["North Goa", "South Goa"],
"Vikarabad": ["North Goa", "South Goa"],
},
"Tamil Nadu": { "Chennai": ["new Delhi", "North Delhi"],
"Kanchipuram": ["Thiruvananthapuram", "Palakkad"],
"Vellore": ["North Goa", "South Goa"],
"Tiruchirappalli": ["North Goa", "South Goa"],
"Madurai": ["North Goa", "South Goa"],
},
"Bihar": { "Aurangabad": ["new Delhi", "North Delhi"],
"Kishanganj": ["Thiruvananthapuram", "Palakkad"],
"Bhojpur": ["North Goa", "South Goa"],
"Araria": ["North Goa", "South Goa"],
"Bhagalpur": ["North Goa", "South Goa"],
},

}
window.onload = function () {
var countySel = document.getElementById("countySel"),
stateSel = document.getElementById("stateSel"),
districtSel = document.getElementById("districtSel");
for (var country in stateObject) {
countySel.options[countySel.options.length] = new Option(country, country);
}
countySel.onchange = function () {
stateSel.length = 1; // remove all options bar first
if (this.selectedIndex < 1) return; // done 
for (var state in stateObject[this.value]) {
stateSel.options[stateSel.options.length] = new Option(state, state);
}
}

}
</script>


</div><br>
<div class="row">
<div class="col-md-6">
<label><b>Address</b></label><br>
<textarea col="3" rows="4" name="address" class="form-control"></textarea><br>
</div>

<div class="col-md-3">
<label><b>Password</b></label>
<input type="text" name="password" placeholder="Enter password" class="form-control">
</div>
</div>

<div class="row">
<div class="col-md-5">
</div>
<div class="col-md-4">
<input type="submit" name="submit" class="btn btn-primary" value="Register">
</div>
</div>

</div>

</form>
</div>
</div>
<?php include'footer.php';?>



<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>































